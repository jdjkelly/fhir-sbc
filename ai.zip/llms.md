# sbc-fhir-ig#0.1.0: Summary of Benefits and Coverage (SBC) FHIR Implementation Guide

## Pages

* [Home](index.md)
* [SBC to FHIR Mapping](mapping.md)
* [Profiles](profiles.md)
* [Artifacts Summary](artifacts.md)
* [Terminology](terminology.md)
* [Examples](examples.md)

## Resources

### CodeSystems

* [SBC Benefit Category Code System](CodeSystem-sbc-benefit-category.md)
* [SBC Plan Type Code System](CodeSystem-sbc-plan-type.md)

### ValueSets

* [SBC Benefit Category Value Set](ValueSet-sbc-benefit-category.md)
* [SBC Plan Type Value Set](ValueSet-sbc-plan-type.md)

### Resource Profiles

* [SBC Insurance Plan Profile](StructureDefinition-sbc-insurance-plan.md)

### Extensions

* [Benefit Limitation Extension](StructureDefinition-benefit-limitation.md)
* [Excluded Services Extension](StructureDefinition-excluded-services.md)
* [SBC Metadata Extension](StructureDefinition-sbc-metadata.md)

### ImplementationGuides

* [Summary of Benefits and Coverage (SBC) FHIR Implementation Guide](index.md)

### Examples

* [Sample Health HMO Gold Plan (InsurancePlan)](InsurancePlan-SBCExampleHMO.md)
* [Sample Health Insurance Company (Organization)](Organization-ExampleIssuerOrg.md)
